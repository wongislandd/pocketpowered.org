# Hexicon — September 2026 marketing refresh

Campaign: **A little wordplay. A world of magic.**

Show the player's choices: spell words, choose a character, shape runes, combine relics and potions, explore branching routes and mysteries, and restore four regions. The PocketPowered landing page leads with native gameplay, then gives each part of the run room to be understood. Android and iPhone beta enrollment remains the conversion goal.

## Assets

- `campaign/`: eight 1080 × 1350 PNG campaign cards and editable HTML sources.
- `social.png`: 1200 × 630 social/link preview.
- `overview.png`: contact sheet of all eight campaign cards.
- `source/`: eighteen fresh 390 × 844 native screenshots, including all four region introductions, maps, and bosses.
- `manifest.json`: copy, dimensions, source commit, and capture provenance.

All game visuals are from Hexicon main at `3e6fd01`, rendered in Godot 4.7.2. The captures use seed 12, an isolated save, unlocked character fixtures, curated inventory and staged words, and explicit phase jumps. They are representative native UI renders, not evidence of one continuous player run. No interface, effect, creature, item, or region was invented for the screenshots. Existing production artwork retains its original provenance in the game asset registers. Marketing framing is HTML/CSS with Georgia and Arial system fonts.

## Reproduce

From the Hexicon repository root:

```sh
godot --headless --editor --path godot --import
godot --path godot --script ../tools/art/capture_marketing.gd
node tools/art/render_marketing.cjs
```

The renderer requires `playwright` (with Chromium) and `sharp` in Node's module search path. `NODE_PATH` may point to a shared installed package directory. Preserve the source captures; edit framing and campaign copy in the renderer.

## Editorial rules

Use current native screenshots for feature claims. Keep text outside the interface. Lead with a recognizable action and one benefit, not catalog counts. Preserve the cream, deep teal, muted green, gold, and pixel-art identity. Do not imply that a curated screenshot is an ordinary opening hand or that every character is unlocked at first launch.

## Verification

Godot capture completed with zero script errors and 18 output screens. Inspected the native screenshots, all eight campaign cards, and social composition. Website validation is recorded separately in its `artifacts/hexicon-marketing` evidence directory.
